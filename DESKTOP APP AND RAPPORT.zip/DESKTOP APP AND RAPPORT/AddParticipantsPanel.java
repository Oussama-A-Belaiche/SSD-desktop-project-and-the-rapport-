import javax.swing.*;

public class AddParticipantsPanel extends JPanel {
    public AddParticipantsPanel() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        JLabel titleLabel = new JLabel("Add Participants");
        JLabel instructionLabel = new JLabel("Enter participant details:");

        JTextField usernameField = new JTextField(15); // Reduced width
        JPasswordField passwordField = new JPasswordField(15); // Reduced width
        JTextField pseudoCodeField = new JTextField(15); // Reduced width

        JButton addButton = new JButton("Add");

        add(titleLabel);
        add(instructionLabel);
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(new JLabel("Pseudo Code:"));
        add(pseudoCodeField);
        add(addButton);
    }
}
