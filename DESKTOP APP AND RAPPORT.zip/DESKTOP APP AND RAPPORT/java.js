
let functionsV= (str1 , str2) => { 

let validation = true ; 
str1 = str1.split("")
str2 = str2.split("") 


str1.forEach((element  ,  index) => {
    element != str2[index] ? validation = false : null 
    
});
if (validation == false )  return "invalide" 
return "valide"

}


console.log(functionsV("oussa" , "oussa"))