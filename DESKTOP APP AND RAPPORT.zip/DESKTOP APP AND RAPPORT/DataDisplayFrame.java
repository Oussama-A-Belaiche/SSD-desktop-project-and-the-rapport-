import javax.swing.*;
import java.awt.*;

public class DataDisplayFrame extends JFrame {
    private JTextArea dataTextArea;

    public DataDisplayFrame() {
        setTitle("Data Display");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); // Dispose on close to avoid exiting the entire application
        setLocationRelativeTo(null);

        dataTextArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(dataTextArea);
        add(scrollPane);

        setVisible(true);
    }

    public void appendData(String data) {
        dataTextArea.append(data);
    }
}
