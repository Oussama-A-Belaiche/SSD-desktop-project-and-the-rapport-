import javax.swing.*;
import java.awt.*;

public class DescriptionPanel extends JPanel {
    public DescriptionPanel() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        JLabel titleLabel = new JLabel("App Description");
        JLabel descriptionLabel = new JLabel("<html>This is a Swing application with multiple panels. Click on the buttons to switch between panels.</html>");
        descriptionLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10)); // Add padding

        add(titleLabel);
        add(descriptionLabel);
    }
}
