import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

public class Proxy {

    private Map<String, Set<String>> communicationMatrix;

    public Proxy() {
        communicationMatrix = new HashMap<>();

       // User1 can talk to all users
Set<String> user1Communication = new HashSet<>();
user1Communication.add("user2");
user1Communication.add("user3");
user1Communication.add("user4");
communicationMatrix.put("user1", user1Communication);

// User2 can talk to only User1 and User4
Set<String> user2Communication = new HashSet<>();
user2Communication.add("user1");
user2Communication.add("user4");
communicationMatrix.put("user2", user2Communication);

// User3 can talk to only User1 
Set<String> user3Communication = new HashSet<>();
user3Communication.add("user1");
communicationMatrix.put("user3", user3Communication);

// User4 can talk to only User1 and User3
Set<String> user4Communication = new HashSet<>();
user4Communication.add("user1");
user4Communication.add("user3");
communicationMatrix.put("user4", user4Communication);

    }

    public void sendMessage(String sender, String receiver, String message) {
        boolean canCommunicate = checkCommunication(sender, receiver);
        if (canCommunicate) {
            displayMessageFrame(sender, receiver, message);
        } else {
            displayCommunicationErrorFrame();
        }
    }

    private boolean checkCommunication(String sender, String receiver) {
        Set<String> allowedReceivers = communicationMatrix.get(sender);
        return allowedReceivers != null && allowedReceivers.contains(receiver);
    }

    private void displayMessageFrame(String sender, String receiver, String message) {
        JFrame frame = new JFrame("Message");
        frame.setSize(300, 200);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel senderLabel = new JLabel("Sender: " + sender);
        JLabel receiverLabel = new JLabel("Receiver: " + receiver);
        JLabel messageLabel = new JLabel("Message: " + message);

        panel.add(senderLabel);
        panel.add(receiverLabel);
        panel.add(messageLabel);

        frame.add(panel);
        frame.setVisible(true);
    }

    private void displayCommunicationErrorFrame() {
        JOptionPane.showMessageDialog(null, "Cannot communicate between these users.", "Communication Error", JOptionPane.ERROR_MESSAGE);
    }
}
