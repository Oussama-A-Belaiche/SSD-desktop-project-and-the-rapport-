import javax.swing.*;
import java.awt.*;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("Main Frame");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600); // Set a fixed size for the frame
        setLocationRelativeTo(null); // Display the frame in the center of the screen
        initComponents();

        setVisible(true);
    }

    private void initComponents() {
        JPanel cards = new JPanel(new CardLayout());

        DescriptionPanel descriptionPanel = new DescriptionPanel();
        AddParticipantsPanel addParticipantsPanel = new AddParticipantsPanel(null);
        SendMessagePanel sendMessagePanel = new SendMessagePanel();
        GenerateKeysPanel generateKeysPanel = new GenerateKeysPanel(); // New panel for generating keys

        cards.add(descriptionPanel, "Description");
        cards.add(addParticipantsPanel, "AddParticipants");
        cards.add(sendMessagePanel, "SendMessage");
        cards.add(generateKeysPanel, "GenerateKeys"); // Add the new panel for generating keys

        getContentPane().add(cards, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 1, 5, 5)); // 4 rows, 1 column, with spacing between buttons
        buttonPanel.setPreferredSize(new Dimension(150, getHeight())); // Fixed width for button panel

        JButton addParticipantsButton = new JButton("Add Participants");
        JButton button2 = new JButton("Messenger");
        JButton button3 = new JButton("Generate Keys"); // Renamed button
        JButton button4 = new JButton("Button 4");

        buttonPanel.add(addParticipantsButton);
        buttonPanel.add(button2);
        buttonPanel.add(button3);
        buttonPanel.add(button4);

        getContentPane().add(buttonPanel, BorderLayout.WEST);

        addParticipantsButton.addActionListener(e -> showPanel(cards, "AddParticipants"));
        button2.addActionListener(e -> showPanel(cards, "SendMessage"));
        button3.addActionListener(e -> showPanel(cards, "GenerateKeys")); // Show the new panel for generating keys
        button4.addActionListener(e -> showPanel(cards, "Button4"));
    }

    private void showPanel(JPanel cards, String panelName) {
        CardLayout cardLayout = (CardLayout) cards.getLayout();
        cardLayout.show(cards, panelName);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}

class DescriptionPanel extends JScrollPane {

    public DescriptionPanel() {
        JTextArea descriptionTextArea = new JTextArea();
        descriptionTextArea.setEditable(false);
        descriptionTextArea.setLineWrap(true);
        descriptionTextArea.setWrapStyleWord(true);

        StringBuilder descriptionText = new StringBuilder();
        descriptionText.append("Desktop Application by Oussama A. Belaiche\n\n");

        descriptionTextArea.setText(descriptionText.toString());

        setViewportView(descriptionTextArea);
        setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    }
}

class AddParticipantsPanel extends JPanel {

    private Map<String, String> legitimateUsers;
    private Set<String> blockedUsers;

    public void displayAddedUser(User user) {
        JFrame frame = new JFrame("Added User");
        frame.setSize(300, 200);
        frame.setLocationRelativeTo(null); // Center the frame on the screen

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Added User Details");
        JLabel usernameLabel = new JLabel("Username: " + user.getUsername());
        JLabel passwordLabel = new JLabel("Password: " + user.getPassword());
        JLabel pseudoCodeLabel = new JLabel("Pseudo Code: " + user.getPseudoCode());

        panel.add(titleLabel);
        panel.add(usernameLabel);
        panel.add(passwordLabel);
        panel.add(pseudoCodeLabel);

        frame.add(panel);
        frame.setVisible(true);
    }

    public AddParticipantsPanel(AddedUserListener addedUserListener) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        legitimateUsers = new HashMap<>();
        legitimateUsers.put("user1", "password1");
        legitimateUsers.put("oussama", "oussama");

        blockedUsers = new HashSet<>();

        JLabel titleLabel = new JLabel("Add Participants");
        JLabel instructionLabel = new JLabel("Enter participant details:");

        JTextField usernameField = new JTextField(15); // Reduced width
        JPasswordField passwordField = new JPasswordField(15); // Reduced width
        JTextField pseudoCodeField = new JTextField(15); // Reduced width

        JButton addButton = new JButton("Add");

        addButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String pseudoCode = pseudoCodeField.getText();

            if (isValidUser(username, password, pseudoCode)) {
                JOptionPane.showMessageDialog(this, "User added successfully!");
                // Notify the listener that a user has been added
                if (addedUserListener != null) {
                    addedUserListener.onUserAdded(new User(username, password, pseudoCode));
                }
            } else {
                // Add the user to the blocked users set
                blockedUsers.add(username);
                // Display a message indicating that the user has been blocked
                JOptionPane.showMessageDialog(this, "Invalid username, password, or pseudo code. User has been added to blocked users.", "Error", JOptionPane.ERROR_MESSAGE);
                // Display the list of blocked users
                showBlockedUsers();
            }
        });

        add(titleLabel);
        add(instructionLabel);
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(new JLabel("Pseudo Code:"));
        add(pseudoCodeField);
        add(addButton);
    }

    private boolean isValidUser(String username, String password, String pseudoCode) {
        // Check if the entered credentials match any legitimate user
        return legitimateUsers.containsKey(username)
                && legitimateUsers.get(username).equals(password)
                && legitimateUsers.get(username).equals(pseudoCode);
    }

    private void showBlockedUsers() {
        StringBuilder blockedUsersMessage = new StringBuilder("Blocked Users:\n");
        for (String user : blockedUsers) {
            blockedUsersMessage.append(user).append("\n");
        }
        JOptionPane.showMessageDialog(this, blockedUsersMessage.toString(), "Blocked Users", JOptionPane.INFORMATION_MESSAGE);
    }
}
// Listener interface for added user
interface AddedUserListener {
    void onUserAdded(User user);
}

// Class to represent a user
class User {
    private String username;
    private String password;
    private String pseudoCode;

    public User(String username, String password, String pseudoCode) {
        this.username = username;
        this.password = password;
        this.pseudoCode = pseudoCode;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getPseudoCode() {
        return pseudoCode;
    }
}

class SendMessagePanel extends JPanel {

    private Map<String, String> legitimateUsers;
    private String hashMessage(String message) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(message.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null; // Handle the exception appropriately in your application
        }
    }
    public SendMessagePanel() {
        
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        // Initialize legitimate users
        legitimateUsers = new HashMap<>();
        legitimateUsers.put("user1", "password1");
        legitimateUsers.put("user2", "password2");
        legitimateUsers.put("user3", "password3");
        legitimateUsers.put("user4", "password4");

        JLabel titleLabel = new JLabel("Send Message");
        JLabel instructionLabel = new JLabel("Enter message and select sender/receiver:");

        JTextField messageField = new JTextField(15);
        JComboBox<String> senderComboBox = new JComboBox<>(legitimateUsers.keySet().toArray(new String[0]));
        JComboBox<String> receiverComboBox = new JComboBox<>(legitimateUsers.keySet().toArray(new String[0]));
        JButton sendButton = new JButton("Send");

       

        sendButton.addActionListener(e -> {
            String message = messageField.getText();
            String sender = (String) senderComboBox.getSelectedItem();
            String receiver = (String) receiverComboBox.getSelectedItem();

            // Hash the message
            String hashedMessage = hashMessage(message);

            Proxy proxy = new Proxy();
            proxy.sendMessage(sender, receiver, hashedMessage);
        });

        add(titleLabel);
        add(instructionLabel);
        add(new JLabel("Message:"));
        add(messageField);
        add(new JLabel("Sender:"));
        add(senderComboBox);
        add(new JLabel("Receiver:"));
        add(receiverComboBox);
        add(sendButton);
    }
}

// Panel for generating keys
class GenerateKeysPanel extends JPanel {

    private Map<String, String> users; 

    public GenerateKeysPanel() {
        setLayout(new BorderLayout()); 

        users = new HashMap<>();
        users.put("user1", "password1");
        users.put("user2", "password2");
        users.put("user3", "password3");
        users.put("user4", "password4");

        JButton generateKeysButton = new JButton("Generate Keys");
        generateKeysButton.addActionListener(e -> {
            try {
                authenticateAndGenerateKeys();
            } catch (NoSuchAlgorithmException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        });

        add(Box.createVerticalGlue(), BorderLayout.NORTH);
        add(generateKeysButton, BorderLayout.CENTER);
        add(Box.createVerticalGlue(), BorderLayout.SOUTH);
    }

    private void authenticateAndGenerateKeys() throws NoSuchAlgorithmException {
        String username = JOptionPane.showInputDialog(this, "Enter username:");
        String password = JOptionPane.showInputDialog(this, "Enter password:");

        if (isValidUser(username, password)) {
            // Authentication successful, generate keys
            KeyGenerator keyGenerator = new KeyGenerator();
            KeyPair keys = keyGenerator.generateKeys();

            // Display the generated keys
            JOptionPane.showMessageDialog(this, "Private Key: " + keys.getPrivateKey() + "\nPublic Key: " + keys.getPublicKey());
        } else {
            // Authentication failed
            JOptionPane.showMessageDialog(this, "Invalid username or password", "Authentication Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean isValidUser(String username, String password) {
        // Validate the user credentials
        return users.containsKey(username) && users.get(username).equals(password);
    }
}

// Class to represent a key pair
class KeyPair {
    private String privateKey;
    private String publicKey;

    public KeyPair(String privateKey, String publicKey) {
        this.privateKey = privateKey;
        this.publicKey = publicKey;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public String getPublicKey() {
        return publicKey;
    }
}

// Class to generate key pairs

class KeyGenerator {
    public KeyPair generateKeys() throws NoSuchAlgorithmException {
        // Generate key pair using RSA algorithm
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(512); // Key size is 512 bits
        java.security.KeyPair keyPair = keyPairGenerator.generateKeyPair();
        
        // Get the private and public keys from the generated key pair
        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();
        
        // Convert keys to Base64 encoded strings for easy representation
        String privateKeyString = Base64.getEncoder().encodeToString(privateKey.getEncoded());
        String publicKeyString = Base64.getEncoder().encodeToString(publicKey.getEncoded());
        
        return new KeyPair(privateKeyString, publicKeyString);
    }
}
 
